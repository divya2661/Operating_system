#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

/* Size and dimensions of Matrices, and the thread pool */
int row1, col1, row2, col2, currentRow = 0, currentCell = 0, InMat1[5005][5005], InMat2[5005][5005], ResMat[5005][5005];
pthread_t * threads;
int numberOfThreads;

/* Mutex for the currentRow and currentCell. */
pthread_mutex_t mutex_Row = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutex_Cell = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t count_threshold_cv = PTHREAD_COND_INITIALIZER;

void prmat()
{
    // Print resultant matrix
    int i, j;
    printf("\nThe resulting matrix is:\n");
    for (i = 0; i < row1; i++)
    {
        printf("|   ");
        for (j = 0; j < col2; j++)
        {
            if(ResMat[i][j]/100000)
                printf("%d ", ResMat[i][j]);
            else if(ResMat[i][j]/10000)
                printf("%d  ", ResMat[i][j]);
            else if(ResMat[i][j]/1000)
                printf("%d   ", ResMat[i][j]);
            else if(ResMat[i][j]/100)
                printf("%d    ", ResMat[i][j]);
            else if(ResMat[i][j]/10)
                printf("%d     ", ResMat[i][j]);
            else
                printf("%d      ", ResMat[i][j]);

        }
        printf("|\n");
    }
}

void* threadworkcw(int Id)
{
    int i, j, myCell, cnt;
    while (1)
    {
        // printf("Locking mutex now for thread %d\n", Id);
        pthread_mutex_lock(&mutex_Cell);
        if (currentCell >= row1*col2)
        {
            pthread_mutex_unlock(&mutex_Cell);
            // printf("Unlocking mutex for thread %d.\n", Id);
            if (Id == 0)
                return;
            pthread_exit(0);
        }
        myCell = currentCell;
        currentCell++;
        pthread_mutex_unlock(&mutex_Cell);
        // printf("Unlocking thread %d and operating on Cell %d of resultant matrix.\n", Id, myCell);

        i = myCell/col2, j = myCell%col2;

        for (cnt = 0; cnt < col1; cnt++)
            ResMat[i][j] += InMat1[i][cnt] * InMat2[cnt][j];
    }
}


void* threadworkrw(int Id)
{
    int i, j, myRow, cnt;
    while (1)
    {
        pthread_mutex_lock(&mutex_Row);
        if (currentRow >= row1)
        {
            pthread_mutex_unlock(&mutex_Row);
            if (Id == 0)
                return;
            pthread_exit(0);
        } 
        myRow = currentRow;
        currentRow++;
        pthread_mutex_unlock(&mutex_Row);

        for (j = 0; j < col2; j++)
            for (i = 0; i < col1; i++)
                ResMat[myRow][j] += InMat1[myRow][i] * InMat2[i][j];
    }
}


int main()
{       
    // Hold for Threads. pthread_t *threads; int numberOfThreads;
    int i, j, k;
    system("clear");
    freopen("in.txt", "r", stdin);
    freopen("out.txt", "w", stdout);
    
    scanf("%d%d",&row1,&col1);
    scanf("%d%d",&row2,&col2);
    
    if (col1 != row2)
    {
        printf("Cannot multiply matrices of given sizes. Program will exit.\n");
        fclose(stdin);
        fclose(stdout);
        return 0;
    }

    scanf("%d",&numberOfThreads);
    
    printf("\nMatrix 1: %d x %d\nMatrix 2: %d x %d\n", row1, col1, row2, col2);
    printf("Total threads: %d\n\n", numberOfThreads);
    

    /* Populate the Matrices. */ 
    for (i = 0; i < row1; i++)
    {
        for (j = 0; j < col1; j++)
            scanf("%d", &InMat1[i][j]);
    }
    printf("\n");
    for (i = 0; i < row2; i++)
    {
        for (j = 0; j < col2; j++)
            scanf("%d", &InMat2[i][j]);
    }

/*___________________________________ROW-WISE_________________________________________*/

    // Initialize resultant matrix
    for (i = 0; i < row1; i++)
        for (j = 0; j < col2; j++)
            ResMat[i][j] = 0;
    

    // create the desired number of threads
    threads = (pthread_t *) malloc(sizeof(pthread_t) * numberOfThreads);
    
    // Start Distributing the work.
    currentRow = 0, currentCell = 0;
    
    struct timespec st, en;
    double runtime;

    clock_gettime(CLOCK_MONOTONIC, &st);
    
    for (i=1; i<numberOfThreads; i++)
        pthread_create(&threads[i], NULL, (void *(*) (void *))threadworkrw, (void *) (i+1));
    
    for (i = 0; i < numberOfThreads; i++)
        pthread_join(threads[i], NULL);

    clock_gettime(CLOCK_MONOTONIC, &en);
    //prmat();
    
    printf("Time taken using multithreading (row-wise): %f seconds.\n", en.tv_sec - st.tv_sec + (en.tv_nsec - st.tv_nsec)/1.0e9);


/*_____________________________________________________________________________________*/



/*___________________________________CELL-WISE_________________________________________*/
    
// Initialize resultant matrix
    for (i = 0; i < row1; i++)
        for (j = 0; j < col2; j++)
            ResMat[i][j] = 0;
    

    // create the desired number of threads
    threads = (pthread_t *) malloc(sizeof(pthread_t) * numberOfThreads);
    
    // Start Distributing the work.
    currentRow = 0, currentCell = 0;
    
    clock_gettime(CLOCK_MONOTONIC, &st);
    
    for (i=1; i<numberOfThreads; i++)
        pthread_create(&threads[i], NULL, (void *(*) (void *))threadworkcw, (void *) (i+1));
    
    for (i = 0; i < numberOfThreads; i++)
        pthread_join(threads[i], NULL);

    clock_gettime(CLOCK_MONOTONIC, &en);
    //prmat();
    
    printf("Time taken using multithreading (cell-wise): %f seconds.\n", en.tv_sec - st.tv_sec + (en.tv_nsec - st.tv_nsec)/1.0e9);

/*_____________________________________________________________________________________*/



/*___________________________________SINGLE-THREAD_____________________________________*/

    // Initialize resultant matrix
    for (i = 0; i < row1; i++)
        for (j = 0; j < col2; j++)
            ResMat[i][j] = 0;
    
    clock_gettime(CLOCK_MONOTONIC, &st);

    for(i=0; i<row1; i++)
    {
        for(j=0; j<col2; j++)
        {
            for(k=0; k<col1; k++)
            {
                ResMat[i][j] += InMat1[i][k] * InMat2[k][j];
            }
        }
    }
    
    clock_gettime(CLOCK_MONOTONIC, &en);
    printf("Time taken without using multithreading: %f seconds.\n", en.tv_sec - st.tv_sec + (en.tv_nsec-st.tv_nsec)/1.0e9);

    prmat();

/*_____________________________________________________________________________________*/


    printf("\nAll calculations are complete.\n\n");
    fclose(stdin);
    fclose(stdout);
    return 0;
}
