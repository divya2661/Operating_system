#include <pthread.h>
#include <semaphore.h>
#include <stdlib.h>
#include <stdio.h>
#define MAX 10
#define Num_customer 50
int customers = 0;
int num_filmfare = 4;
int value;
pthread_t cust[Num_customer];
pthread_t barb[3];
sem_t mutex,chair,barber,customer,cash,reciept,mutex1;

typedef struct{
    sem_t went;
    sem_t left;
}queue;

queue *waiting_room,*filmfare,*os;

queue* create_queue(int num)
{
    queue* F=(queue*)malloc(sizeof(queue));
    sem_init(&(F->went),0,0);
    sem_init(&(F->left),0,num);
    return(F);
}

int wait_queue(queue* F,int n)
{
    sem_getvalue(&F->left,&value);
    sem_wait(&(F->left));
    sem_post(&(F->went));
    return value;
    
}

void signal_queue(queue* F)
{
        sem_wait(&(F->went));
        sem_post(&(F->left));
        
}

void* barbershop(void *arg)
{
    
    int n=*(int *)arg;

    int left_ff;
    
    sem_wait(&mutex); //lock at a time so that other thread can not change the value of "customer" and we can check
                        //customer is shared variable among threds  
    if(customers>=MAX)   
    {
        sem_post(&mutex);
        printf("Sorry! we don't have space. exiting shop %d..\n",n);//exit_shop();
    }
    
    customers+=1;
    
    sem_post(&mutex);
    
    wait_queue(waiting_room,n);//standing_room_wait(); left++; went--; max_capacity = 16
    
    printf("Entering to waiting room %d\n",n);//enter_waiting room();
    
    if(wait_queue(filmfare,n)==0)
    {
        printf("Reading Os Book %d\n",n); 
    }//If filmfare is 0 the acquire a os book 
    
    
    printf("Reading filmfare %d\n",n); //filmfare(reading);}    

    signal_queue(waiting_room);//standing_room_signal(); leaving waiting room and entering into shop for hair cut 
    //num_filmfare++;
    
    sem_wait(&chair); // acquire chair
    
    printf("\tsit barber chair for haircut %d\n",n);//SitOnBarberChair();
    
    sleep(3);
    //signal_queue(os);
    
    signal_queue(filmfare); //signaling filmfare after leaving.
    
    sem_post(&customer); //customer increase

    sem_wait(&barber); // barber acquired.
    
    printf("\tGet hair Cut %d\n",n);//getHairCut();
    
    sleep(2);
    
    printf("\t\tCustomer %d got the haircut. Ready to pay.\n",n);//pay();
    
    sem_post(&cash);
    
    sem_wait(&reciept);
    
    sem_wait(&mutex); //lock for changing customer. only one thread will change the customer value at a time.
    
    customers-=1;
    
    sem_post(&mutex);
    
    printf("\t\t\t -----------------\n\t\t\tCustomer %d is saying thank you for service. Exiting shop\n\t\t\t----------------\n",n);
}

void* cutting(void* arg)
{
    int n=*(int *)arg;
    while(1)
    {
        
            sem_wait(&customer);
            sem_post(&barber);
            printf("\tbarber %d cutting hair\n",n);
            sleep(3);
            sem_wait(&cash);
            printf("\tbarber %d accpting payment\n",n);
            sleep(1);
            sem_post(&reciept);
            sem_post(&chair);
        
    }
}
main()
{
    int i,j,cust_id[Num_customer];
    char ch;
    sem_init(&mutex,0,1);
    //sem_init(&mutex1,0,1);
    sem_init(&chair,0,3);
    sem_init(&barber,0,0);
    sem_init(&customer,0,0);
    sem_init(&cash,0,0);
    sem_init(&reciept,0,0);
    waiting_room=create_queue(6);
    filmfare=create_queue(4);
    os = create_queue(50);
    for(i=0;i<3;i++)
    {
        cust_id[i]=i;
        pthread_create(&barb[i],0,cutting,&cust_id[i]);
        printf("barber %d is sleeping\n",i );
    }
   
   printf("Please Enter customer by pressing C key and E to exit.\n");
    j=0;
    while(1){
        scanf("%c",&ch);
        if(ch=='c'){
            cust_id[j]=j;
            pthread_create(&cust[i],0,barbershop,&cust_id[j]);
            j++;
        }
        if(ch=='e'){
            return(0);
        }
    }
    while(1);
}
